import React from 'react'
import { toast } from 'react-hot-toast'
import Cookies from "js-cookie";
import { useNavigate, useLocation } from "react-router-dom";
import { httpPost } from "../Helpers/HttpConfig"
import Constants from '../constant';
import { useAuth } from "../Hooks/auth";

const VerifyOtpComponent = (OriginalComponent) => {

    const NewComponent = (props) => {
        const navigate = useNavigate()
        const location = useLocation()
        const { verifyToken } = useAuth()
        const path = location.state?.from?.pathname || "/";
        //To verify otp
        const verifyOtp = async (event, inputfields) => {
            event.preventDefault()
            console.log("verifyOtp...")
            const toastId = toast.loading('Loading...', { duration: 1000 });
            let { email, otp, role, user_name } = inputfields
            let userName = email ? email : user_name
            try {
                let response = await httpPost(
                    Constants.reqUrl + "/api/users/verify_otp", {
                    "user_id": userName,
                    "otp": otp,
                    "role": role,
                    "timezone": "asia/kolkata"
                }
                );
                if (response.data.isOtpVerified) {
                    toast.success(response.data.message, {
                        id: toastId,
                    })
                    Cookies.set("accessToken", response.data.token);
                    console.log("props...", props.path)
                    await verifyToken()
                    navigate(path, { replace: true })
                } else {
                    toast.error(response.data.message, {
                        id: toastId,
                    })
                }
            } catch (err) {
                console.log(err)
                toast.error(err.response.data.errorMsg, {
                    id: toastId,
                    duration: 1000,
                })
            }
        }

        //To resend the otp
        const resendOtp = async (event, inputfields) => {
            event.preventDefault()
            const toastId = toast.loading('Loading...', { duration: 1000 });
            let { email, user_name } = inputfields
            let userName = email ? email : user_name
            try {
                let response = await httpPost(
                    Constants.reqUrl + "/api/users/resend_otp", {
                    "user_id": userName,
                });
                if (!response.error) {
                    toast.success(response.data.message, {
                        id: toastId,
                    })
                }
            } catch (err) {
                console.log(err)
                toast.error(err.response.data.errorMsg, {
                    id: toastId,
                    duration: 1000,
                })
            }
        }
        return <OriginalComponent verifyOtp={verifyOtp} resendOtp={resendOtp} {...props} />
    }
    return (
        NewComponent
    )
}

export default VerifyOtpComponent
