import React, { createContext, useContext, useRef } from 'react'
import { httpProtectedPost } from "../Helpers/HttpConfig"
import Constants from "../constant"

const AuthContext = createContext(null)

export const AuthProvider = ({ children }) => {
    const authorized = useRef(false)

    const verifyToken = async () => {
        console.log("i am in verify token api")
        await httpProtectedPost(
            Constants.reqUrl + "/api/users/verify_token").then((response) => {
                if (response.data.isTokenVerified) {
                    authorized.current = true
                }
            }).catch((err) => {
                authorized.current = false
                console.log("err..", err)
            })
        console.log("authorized....", authorized)
    }
    return (
        <AuthContext.Provider value={{ authorized, verifyToken }}>
            {children}
        </AuthContext.Provider>
    )
}

export const useAuth = () => {
    return useContext(AuthContext)
}