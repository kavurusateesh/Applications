import axios from "axios";
import Cookies from "js-cookie";


//common method for all post requests
export async function httpPost(url, postdata) {
    return await axios.post(url, postdata)
};

export async function httpProtectedPost(url, postdata) {
    const options = {
        headers: { Authorization: "Bearer " + Cookies.get("accessToken") },
    }
    return await axios.post(url, postdata, options)
};

// module.exports = { httpPost, httpProtectedPost }