module.exports = {
    imgurl: (function () {
        if (typeof window !== "undefined") {
            let url = window.location.host;
            if (url === "localhost:3000") {
                return "http://localhost:3000";
            } else if (url === "sunshinestaging.medleymed.com") {
                return "https://sunshinestaging.medleymed.com";
            } else {
                return "https://sunshinestaging.medleymed.com";
            }
        }
    })(),
    reqUrl: "http://localhost:8080"
}