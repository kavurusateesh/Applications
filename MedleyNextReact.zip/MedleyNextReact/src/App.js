import Routes from './Routes/index'

function App() {
  return (
    <div className="App" >
      <Routes />
    </div>
  );
}

export default App;





