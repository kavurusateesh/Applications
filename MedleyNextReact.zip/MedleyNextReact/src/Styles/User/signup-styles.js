import { makeStyles } from "@mui/styles";
//import bannerImage from "../../Assets/Images/consult_doctor_banner.png";

const signuprStyles = makeStyles(theme => ({
    imgStyle: {
        height: '650px',
        marginTop: `27px`,
        borderRadius: `10px`,
        backgroundColor: `white`,
        marginRight: `30px`,
        marginLeft: `26px`,
        backgroundImage: `linear-gradient(rgba(0,0,0,0),rgba(0,0,0,0)),url('https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-registration/draw1.webp')`,
        backgroundSize: '98%',
        justifyContent: `center`,
        backgroundPosition: "center",
        backgroundRepeat: `no-repeat`,
    }
}))



export { signuprStyles } 