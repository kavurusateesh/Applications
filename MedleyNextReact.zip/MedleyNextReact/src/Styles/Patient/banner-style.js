import { makeStyles } from "@mui/styles";
import bannerImage from "../../Assets/Images/consult_doctor_banner.png";

const bannerStyles = makeStyles(theme => ({
    banner: {
        backgroundImage: `linear-gradient(rgba(0,0,0,0),rgba(0,0,0,0.1)),url(${bannerImage})`,
        height: '300px',
        backgroundPosition: "center",
        backgroundRepeat: `no-repeat`,
        backgroundSize: `cover`,
        position: `relative`,
        display: `flex`,
        justifyContent: `center`,
        alignItems: `center`,
        color: `#fff`,
        fontSize: `4rem`,
        marginLeft: `93px`,
        marginRight: `93px`,
        marginTop: `10px`,
        borderRadius: `10px`
    }
}))

const commonHealthConcerns = makeStyles(theme => ({
    root: {
        flexGrow: 1
    },
    health_concerns: {
        height: '300px',
        marginLeft: `93px`,
        marginRight: `93px`,
        marginTop: `10px`,
        borderRadius: `10px`,
    }

}))

export { bannerStyles, commonHealthConcerns } 