import { makeStyles } from "@mui/styles";

const modalStyles = makeStyles(theme => ({
    modalStyle: {
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        width: 600,
        height: 500,
        backgroundColor: '#fff',
        borderRadius: '6px',
        boxShadow: 30,
    }
}))



export { modalStyles } 