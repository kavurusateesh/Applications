import React from 'react'
import PatientRoutes from './Ptient/index'
import { BrowserRouter } from "react-router-dom";
import { AuthProvider } from "../Hooks/auth"

export default function index() {
    console.log("main index route...")
    return (
        <BrowserRouter>
            <AuthProvider>
                <PatientRoutes />
            </AuthProvider>
        </BrowserRouter>
    )
}
