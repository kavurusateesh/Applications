import React from 'react'
import PatientRoutes from './PatientRoutes'

export default function index() {
    return (
        <div>
            <PatientRoutes />
        </div>
    )
}
