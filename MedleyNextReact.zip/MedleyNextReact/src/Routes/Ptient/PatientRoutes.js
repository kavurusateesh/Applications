import { Routes, Route } from "react-router-dom";
import { Dashboard, PatientSignup, PatientLogin, PatientProfile } from "../../containers"
import { PatientLayout, UserRequireAuth } from "../../components/index"

const patientPath = "/patient"


export default function PatientRoutes() {
    console.log("patient signup...")

    return (
        <Routes>
            <Route path="/" element={<PatientLayout path={`${patientPath}/login`} />}>
                <Route index element={<Dashboard />} />
                {/* <Route path={`${patientPath}/signup`} element={!authorized ? <PatientSignup /> : <Navigate to={`${patientPath}/profile`} />} />
                <Route path={`${patientPath}/login`} element={!authorized ? <PatientLogin /> : <Navigate to={`${patientPath}/profile`} />} /> */}

                <Route path={`${patientPath}/signup`} element={<PatientSignup />} />
                <Route path={`${patientPath}/login`} element={<PatientLogin />} />


                {/* we want to protect these routes */}
                <Route element={<UserRequireAuth path={`${patientPath}/login`} />}>
                    <Route path={`${patientPath}/profile`} element={<PatientProfile />} />
                </Route>
                <Route path="*" element={<div><h1>No Data</h1></div>} />
            </Route>
        </Routes>
    )
}
