// import React from 'react'
// import { Routes, Route } from "react-router-dom";
// import { UserSignup, Dashboard } from "../../containers/index"
// const patientPath = "/patient"


// export default function UserRoutes() {
//     return (
//         <Routes>
//             <Route index element={<Dashboard />} />
//             <Route path={`${patientPath}/signup`} element={<UserSignup />} />
//             {/* <Route index element={<Dashboard />} />
//             <Route path={`${patientPath}/signup`} element={<UserSignup />} /> */}
//         </Routes>
//     )
// }
