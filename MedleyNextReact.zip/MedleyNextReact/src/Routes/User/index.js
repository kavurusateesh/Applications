import React from 'react'
import UserRoutes from './UserRoutes'

export default function index() {
    return (
        <div>
            <UserRoutes />
        </div>
    )
}
