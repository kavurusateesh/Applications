import { red } from '@mui/material/colors';
import { createTheme } from '@mui/material/styles';


// A custom theme for this app
const theme = createTheme({
    palette: {
        primary: {
            main: '#764abc',
            contrastText: '#002884',
        },
        secondary: {
            main: '#19857b',
        },
        error: {
            main: red.A400,
        },
        background: {
            default: `#E0E0E0`,
        },
    },
    components: {
        MuiButton: {
            variants: [
                {
                    props: { variant: 'dashed' },
                    style: {
                        textTransform: 'none',
                        border: `2px dashed #E0E0E0`,
                    },
                },
                {
                    props: { variant: "contained", color: 'primary' },
                    style: {
                        textTransform: 'none',
                        color: '#fff'
                    },
                },
            ]
        },
    }


});

export default theme;