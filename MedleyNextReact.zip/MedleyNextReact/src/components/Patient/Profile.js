import React from 'react'
import { Modal, Button, Box, Grid, Typography, Input, FormControl, FormLabel, RadioGroup, FormControlLabel, Radio, TextField } from '@mui/material';
import DateFnsUtils from '@date-io/date-fns';
import { DatePicker, MuiPickersUtilsProvider } from "@material-ui/pickers";
import { modalStyles } from '../../Styles/Patient/modal'

export default function Profile() {
    const classes = modalStyles()
    const [open, setOpen] = React.useState(false);
    const [selectedDate, setSelectedDate] = React.useState(new Date());

    const handleOpen = () => {
        setOpen(true);
    };
    const handleClose = () => {
        setOpen(false);
    };
    const handleDateChange = () => {

    };
    return (
        <div>
            <Button onClick={handleOpen}>Open Child Modal</Button>
            <Modal
                hideBackdrop
                open={open}
                onClose={handleClose}
                aria-labelledby="child-modal-title"
                aria-describedby="child-modal-description"
            >
                <Box className={classes.modalStyle}>
                    <Grid container display="flex" align="center">
                        <Grid item xs={12}>
                            <Typography variant="h5" component="h5" sx={{ paddingBottom: '30px', paddingTop: '30px', fontWeight: 'bold' }}>
                                Update Profile
                            </Typography>
                        </Grid>
                        <Grid item xs={12}>
                            <Input type='text' placeholder='Name' sx={{ width: '50%' }}></Input>
                        </Grid>
                        <Grid item sx={{ paddingTop: `20px`, paddingLeft: `0px` }} xs={12}>
                            <FormControl sx={{ width: '50%' }}>
                                <FormLabel id="demo-radio-buttons-group-label" sx={{ width: '20%' }}>Gender</FormLabel>
                                <RadioGroup
                                    aria-labelledby="demo-radio-buttons-group-label"
                                    defaultValue="female"
                                    name="radio-buttons-group"
                                >
                                    <FormControlLabel value="female" control={<Radio />} label="Female" />
                                    <FormControlLabel value="male" control={<Radio />} label="Male" />
                                    <FormControlLabel value="other" control={<Radio />} label="Other" />
                                </RadioGroup>
                            </FormControl>
                        </Grid>
                        <Grid item sx={{ paddingTop: `20px` }} justify="space-around" xs={12}>
                            <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                <DatePicker
                                    openTo="year"
                                    format="dd/MM/yyyy"
                                    label="Date of birth"
                                    className="DatePicker"
                                    renderInput={(params) => (
                                        <TextField
                                            {...params}
                                            sx={{
                                                height: "200px",
                                                width: "100%"
                                            }}

                                        />
                                    )}
                                    views={["year", "month", "date"]}
                                    value={selectedDate}
                                    onChange={handleDateChange}
                                />
                            </MuiPickersUtilsProvider>
                        </Grid>
                    </Grid>
                    <Button variant='contained' type='submit' sx={{ float: 'right', marginRight: '20px' }}>Update</Button>
                </Box>
            </Modal>
        </div>
    )
}
