import { Outlet } from "react-router-dom"
import Header from "./Header"

const Layout = (props) => {
    const { path } = props
    return (
        <main className="App">
            <Header path={path} />
            <Outlet />
        </main>
    )
}

export default Layout