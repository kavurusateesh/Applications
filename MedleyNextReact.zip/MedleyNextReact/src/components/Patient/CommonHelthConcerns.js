
import * as React from 'react';
import { Card, CardContent, CardMedia, Typography, Grid } from '@mui/material';
import { commonHealthConcerns } from '../../Styles/Patient/banner-style'
import DermatologyImg from "../../Assets/Images/1658490447545.jpg"
import EmergencyImg from "../../Assets/Images/1646825192766.jpg"
import EntImg from "../../Assets/Images/1646825215335.jpg"


export default function CommonHelthConcerns() {
    const classes = commonHealthConcerns()
    return (
        <div className={classes.health_concerns}>
            <Typography variant="h5" component="h5" sx={{ marginBottom: '30px', marginTop: '30px', fontWeight: 'bold' }}>
                Common Helth Concerns
            </Typography>
            <Grid container>
                <Grid item xs={3}>
                    <Card sx={{ maxWidth: 250, maxHeight: 290 }}>
                        <CardMedia
                            component="img"
                            height="200"
                            image={DermatologyImg}
                            alt="green iguana"
                        />
                        <CardContent>
                            <Typography gutterBottom variant="h5" component="div">
                                Dermatology
                            </Typography>
                            <Typography variant="body2" color="text.primary">
                                consult now
                            </Typography>
                        </CardContent>

                    </Card>
                </Grid>
                <Grid item xs={3}>
                    <Card sx={{ maxWidth: 250, maxHeight: 290 }}>
                        <CardMedia
                            component="img"
                            height="200"
                            image={EmergencyImg}
                            alt="green iguana"
                        />
                        <CardContent>
                            <Typography gutterBottom variant="h5" component="div">
                                Dermatology
                            </Typography>
                            <Typography variant="body2" color="text.primary">
                                consult now
                            </Typography>
                        </CardContent>

                    </Card>
                </Grid>
                <Grid item xs={3}>
                    <Card sx={{ maxWidth: 250, maxHeight: 290 }}>
                        <CardMedia
                            component="img"
                            height="200"
                            image={EntImg}
                            alt="green iguana"
                        />
                        <CardContent>
                            <Typography gutterBottom variant="h5" component="div">
                                Dermatology
                            </Typography>
                            <Typography variant="body2" color="text.primary">
                                consult now
                            </Typography>
                        </CardContent>

                    </Card>
                </Grid>
                <Grid item xs={3}>
                    <Card sx={{ maxWidth: 250, maxHeight: 290 }}>
                        <CardMedia
                            component="img"
                            height="200"
                            image={DermatologyImg}
                            alt="green iguana"
                        />
                        <CardContent>
                            <Typography gutterBottom variant="h5" component="div">
                                Dermatology
                            </Typography>
                            <Typography variant="body2" color="text.primary">
                                consult now
                            </Typography>
                        </CardContent>

                    </Card>
                </Grid>
            </Grid>
        </div>
    );
}
