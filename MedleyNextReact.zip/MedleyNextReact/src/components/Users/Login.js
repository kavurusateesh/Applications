import React, { useEffect, useState } from 'react'
import { Button, Box, Grid, Typography, Input } from '@mui/material';
// import DateFnsUtils from '@date-io/date-fns';
// import { DatePicker, MuiPickersUtilsProvider } from "@material-ui/pickers";
import { signuprStyles } from "../../Styles/User/signup-styles"
import { httpPost } from "../../Helpers/HttpConfig"
import Constants from '../../constant';
import { Toaster, toast } from 'react-hot-toast'
import VerifyOtpComponent from '../../HOC/VerifyOtp';
import { useAuth } from "../../Hooks/auth";
import { useLocation, useNavigate } from "react-router-dom";


const Login = (props) => {
    let { verifyOtp, resendOtp, path } = props
    console.log("path...", path)
    const classes = signuprStyles()
    const { authorized, verifyToken } = useAuth()

    const location = useLocation()
    const navigatePath = location.state?.from?.pathname || "/";
    const navigate = useNavigate()
    const [inputfields, setInputfields] = useState({ user_name: '', otp: '', role: "patient" });
    const [isUserLoggedin, setUserLoggedin] = useState(false);

    useEffect(() => {
        (async function () {
            await verifyToken()
            if (authorized.current && path !== "/patient/login") navigate(navigatePath, { replace: true })
        })()

    })

    //To Register the user
    const login = async (event) => {
        event.preventDefault()
        const toastId = toast.loading('Loading...');
        //Condition is used to stop multi popups
        if (toastId !== "1")
            toast.dismiss(toastId)
        let { user_name, role } = inputfields
        try {
            let response = await httpPost(
                Constants.reqUrl + "/api/users/login", {
                user_name,
                role
            });
            if (!response.data.error) {
                toast.success(response.data.message, {
                    id: toastId,
                })
                setUserLoggedin(true)
            }
        } catch (err) {
            toast.error(err.response.data.errorMsg, {
                id: toastId,
                duration: 1000,
            })
        }
    };


    // When value changes on input Fields
    const updateInputValue = (event, field) => {
        setInputfields({ ...inputfields, [field]: event.target.value });
    };

    return (
        <div>
            <Box sx={{
                height: '700px',
                marginLeft: `93px`,
                marginRight: `93px`,
                marginTop: `20px`,
                borderRadius: `10px`,
                backgroundColor: `white`,
                display: "flex",
                alignItems: "center"
            }} >
                <Toaster position="top-right"
                    reverseOrder={false} />
                <Grid container>
                    <Grid item xs={6} className={classes.imgStyle} />
                    <Grid item xs={6} sx={{ paddingTop: "15%", alignItems: "center" }}>
                        {!isUserLoggedin ? <form onSubmit={(event) => login(event)} id='patientForm'>
                            <Grid container align="center">
                                <Grid item xs={12}>
                                    <Typography variant="h5" component="h5" sx={{ paddingBottom: '30px', paddingTop: '30px', fontWeight: 'bold' }}>
                                        Login
                                    </Typography>
                                </Grid>
                                <Grid item xs={12}>
                                    <Input type='text' placeholder='Email or Phone Number' value={inputfields.user_name} sx={{ width: '50%' }} onChange={(event) => updateInputValue(event, 'user_name')}></Input>
                                </Grid>

                                <Grid item xs={12} sx={{ paddingTop: `20px` }}>
                                    <Button sx={{ marginRight: '30px' }} variant='contained' type='submit'>Login</Button>
                                    <Button variant='contained' onClick={() => { document.getElementById("patientForm").reset() }}>Re-Set</Button>
                                </Grid>

                            </Grid>
                        </form>
                            : <form onSubmit={(event) => verifyOtp(event, inputfields)} id='patientForm'>
                                <Grid container display="flex" align="center">
                                    <Grid item xs={12}>
                                        <Typography variant="h5" component="h5" sx={{ paddingBottom: '30px', paddingTop: '30px', fontWeight: 'bold' }}>
                                            OTP-Verification
                                        </Typography>
                                    </Grid>
                                    <Grid item xs={12}>
                                        <Input type='text' placeholder='Enter OTP' value={inputfields.otp} sx={{ width: '50%' }} onChange={(event) => updateInputValue(event, 'otp')}></Input>
                                    </Grid>

                                    <Grid item xs={12} sx={{ paddingTop: `20px` }}>
                                        <Button sx={{ marginRight: '30px' }} variant='contained' type='submit'>Verify</Button>
                                        <Button variant='contained' onClick={(event) => resendOtp(event, inputfields)} >Resend OTP</Button>
                                    </Grid>
                                </Grid>
                            </form>}
                    </Grid>
                </Grid >
            </Box>
        </div>
    )
}

export default VerifyOtpComponent(Login)
