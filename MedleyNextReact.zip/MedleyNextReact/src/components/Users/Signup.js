import React, { useState } from 'react'
import Cookies from "js-cookie";
import { Button, Box, Grid, Typography, Input } from '@mui/material';
// import DateFnsUtils from '@date-io/date-fns';
// import { DatePicker, MuiPickersUtilsProvider } from "@material-ui/pickers";
import { signuprStyles } from "../../Styles/User/signup-styles"
import { httpPost } from "../../Helpers/HttpConfig"
import Constants from '../../constant';
import { Toaster, toast } from 'react-hot-toast'
import VerifyOtpComponent from '../../HOC/VerifyOtp';


const Signup = (props) => {
    let { verifyOtp, resendOtp } = props
    const classes = signuprStyles()
    const [inputfields, setInputfields] = useState({ email: '', phoneNumber: '', otp: '', role: 'patient' });
    const [isUserRegistered, setIsUserRegistered] = useState(false);

    //To Register the user
    const signup = async (event) => {
        event.preventDefault()
        const toastId = toast.loading('Loading...');
        //Condition is used to stop multi popups
        if (toastId !== "1")
            toast.dismiss(toastId)
        let { phoneNumber, email } = inputfields
        try {
            let response = await httpPost(
                Constants.reqUrl + "/api/users/signup", {
                "role": 'patient',
                "email": email,
                "phone_number": phoneNumber
            });
            if (!response.data.error) {
                toast.success(response.data.message, {
                    id: toastId,
                })
                setIsUserRegistered(true)
            }
        } catch (err) {
            toast.error(err.response.data.errorMsg, {
                id: toastId,
                duration: 1000,
            })
        }
    };

    // //To resend the otp
    // const resendOtp = async (event) => {
    //     const toastId = toast.loading('Loading...', { duration: 1000 });
    //     event.preventDefault()
    //     let { email } = inputfields
    //     try {
    //         let response = await httpPost(
    //             Constants.reqUrl + "/api/users/resend_otp", {
    //             "user_id": email,
    //         });
    //         if (!response.error) {
    //             toast.success(response.data.message, {
    //                 id: toastId,
    //             })
    //         }
    //     } catch (err) {
    //         console.log(err)
    //         toast.error(err.response.data.errorMsg, {
    //             id: toastId,
    //             duration: 1000,
    //         })
    //     }
    // }


    //To verify otp
    // const verifyOtp = async (event) => {
    //     event.preventDefault()
    //     const toastId = toast.loading('Loading...', { duration: 1000 });
    //     let { email, otp } = inputfields
    //     try {
    //         let response = await httpPost(
    //             Constants.reqUrl + "/api/users/verify_otp", {
    //             "user_id": email,
    //             "otp": otp
    //         }
    //         );
    //         if (response.data.isOtpVerified) {
    //             toast.success(response.data.message, {
    //                 id: toastId,
    //             })

    //         } else {
    //             Cookies.set("accessToken", response.token);
    //             toast.error(response.data.message, {
    //                 id: toastId,
    //             })
    //         }
    //     } catch (err) {
    //         console.log(err)
    //         toast.error(err.response.data.errorMsg, {
    //             id: toastId,
    //             duration: 1000,
    //         })
    //     }
    // }

    // When value changes on input Fields
    const updateInputValue = (event, field) => {
        setInputfields({ ...inputfields, [field]: event.target.value });
    };

    return (
        <div>
            <Box sx={{
                height: '700px',
                marginLeft: `93px`,
                marginRight: `93px`,
                marginTop: `20px`,
                borderRadius: `10px`,
                backgroundColor: `white`,
                display: "flex",
                alignItems: "center"
            }} >
                <Toaster position="top-right"
                    reverseOrder={false} />
                <Grid container>
                    <Grid item xs={6} className={classes.imgStyle} />
                    <Grid item xs={6} sx={{ display: "flex", alignItems: "center" }}>
                        {!isUserRegistered ? <form onSubmit={(event) => signup(event)} id='patientForm'>
                            <Grid container display="flex" align="center">
                                <Grid item xs={12}>
                                    <Typography variant="h5" component="h5" sx={{ paddingBottom: '30px', paddingTop: '30px', fontWeight: 'bold' }}>
                                        Signup
                                    </Typography>
                                </Grid>
                                {/* <Grid item>
                                <Input type='text' placeholder='Name' sx={{ width: '50%' }}></Input>
                            </Grid> */}

                                <Grid item xs={12}>
                                    <Input type='text' placeholder='Email' value={inputfields.email} sx={{ width: '50%' }} onChange={(event) => updateInputValue(event, 'email')}></Input>
                                </Grid>
                                <Grid item xs={12} sx={{ paddingTop: `20px` }}>
                                    <Input type='text' placeholder='Mobile Number' value={inputfields.phoneNumber} sx={{ width: '50%' }} onChange={(event) => updateInputValue(event, 'phoneNumber')}></Input>
                                </Grid>
                                {/* <Grid item sx={{ paddingTop: `20px`, paddingLeft: `0px` }}>
                                <FormControl sx={{ width: '50%' }}>
                                    <FormLabel id="demo-radio-buttons-group-label" sx={{ width: '20%' }}>Gender</FormLabel>
                                    <RadioGroup row
                                        aria-labelledby="demo-radio-buttons-group-label"
                                        defaultValue="female"
                                        name="radio-buttons-group"
                                    >
                                        <FormControlLabel value="female" control={<Radio />} label="Female" />
                                        <FormControlLabel value="male" control={<Radio />} label="Male" />
                                        <FormControlLabel value="other" control={<Radio />} label="Other" />
                                    </RadioGroup>
                                </FormControl>
                            </Grid> */}
                                {/* <Grid item sx={{ paddingTop: `20px` }} justify="space-around">
                                <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                    <DatePicker
                                        openTo="year"
                                        format="dd/MM/yyyy"
                                        label="Date of birth"
                                        className="DatePicker"
                                        renderInput={(params) => (
                                            <TextField
                                                {...params}
                                                sx={{
                                                    height: "200px",
                                                    width: "100%"
                                                }}

                                            />
                                        )}
                                        views={["year", "month", "date"]}
                                        value={selectedDate}
                                        onChange={handleDateChange}
                                    />
                                </MuiPickersUtilsProvider>
                            </Grid> */}
                                {/* <Grid item sx={{ paddingTop: `20px` }}>
                                <Input type='password' placeholder='Password' sx={{ width: '50%' }}></Input>
                            </Grid>
                            <Grid item sx={{ paddingTop: `20px` }}>
                                <Input type='password' placeholder='Re-Enter Password' sx={{ width: '50%' }}></Input>
                            </Grid>
                            <Grid item sx={{ paddingTop: `20px` }}>
                                <FormControl variant="standard" sx={{ m: 1, width: '50%' }}>
                                    <InputLabel>Signup As</InputLabel>
                                    <Select
                                        // value={age}
                                        // onChange={handleChange}
                                        label="Age"
                                    >
                                        <MenuItem value="">
                                            <em>None</em>
                                        </MenuItem>
                                        <MenuItem value={10}>Customer</MenuItem>
                                        <MenuItem value={20}>Doctor</MenuItem>

                                    </Select>
                                </FormControl>
                            </Grid> */}
                                <Grid item xs={12} sx={{ paddingTop: `20px` }}>
                                    <Button sx={{ marginRight: '30px' }} variant='contained' type='submit'>Sign Up</Button>
                                    <Button variant='contained' onClick={() => { document.getElementById("patientForm").reset() }}>Re-Set</Button>
                                </Grid>

                            </Grid>
                        </form>
                            : <form onSubmit={(event) => verifyOtp(event, inputfields)} id='patientForm'>
                                <Grid container display="flex" align="center">
                                    <Grid item xs={12}>
                                        <Typography variant="h5" component="h5" sx={{ paddingBottom: '30px', paddingTop: '30px', fontWeight: 'bold' }}>
                                            OTP-Verification
                                        </Typography>
                                    </Grid>
                                    <Grid item xs={12}>
                                        <Input type='text' placeholder='Enter OTP' value={inputfields.otp} sx={{ width: '50%' }} onChange={(event) => updateInputValue(event, 'otp')}></Input>
                                    </Grid>

                                    <Grid item xs={12} sx={{ paddingTop: `20px` }}>
                                        <Button sx={{ marginRight: '30px' }} variant='contained' type='submit'>Verify</Button>
                                        <Button variant='contained' onClick={(event) => resendOtp(event, inputfields)} >Resend OTP</Button>
                                    </Grid>
                                </Grid>
                            </form>}
                    </Grid>
                </Grid >

            </Box>
        </div>
    )
}


export default VerifyOtpComponent(Signup)