import { useLocation, Navigate, Outlet } from "react-router-dom";
import { useAuth } from "../../Hooks/auth";

const RequireAuth = (props) => {
    const { path } = props
    const { authorized } = useAuth();
    console.log("required auth..", authorized)
    const location = useLocation();

    return (
        authorized.current ? <Outlet />
            : <Navigate to={path} state={{ from: location }} replace />
    );
}

export default RequireAuth;