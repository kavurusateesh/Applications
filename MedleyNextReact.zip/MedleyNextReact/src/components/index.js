import HeaderComponent from "./Patient/Header";
import CommonHelthConcernsComponent from "./Patient/CommonHelthConcerns";
import PatientProfileComponent from "./Patient/Profile";
import PatientLayoutComponent from "./Patient/Layout"

import UserSignupComponent from "./Users/Signup"
import UserLoginComponent from "./Users/Login"
import UserRequireAuthComponent from "./Users/RequireAuth"

//Patient components
const Header = (props) => { return (<HeaderComponent {...props} />) }
const CommonHelthConcerns = () => { return (<CommonHelthConcernsComponent />) }
const PatientProfile = () => { return (<PatientProfileComponent />) }
const PatientLayout = (props) => { return (<PatientLayoutComponent {...props} />) }

//user components
const UserSignup = () => { return (<UserSignupComponent />) }
const UserLogin = (props) => { return (<UserLoginComponent {...props} />) }
const UserRequireAuth = (props) => { return (<UserRequireAuthComponent {...props} />) }

export { Header, CommonHelthConcerns, UserSignup, UserLogin, PatientProfile, PatientLayout, UserRequireAuth }