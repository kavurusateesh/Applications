import DashboardContainer from "./Patient/Dashboard";
import PatientSignupContainer from "./Patient/Signup";
import PatientLoginContainer from "./Patient/Login"
import PatientProfileContainer from "./Patient/Profile"

//Patient containers
const Dashboard = () => { return (<DashboardContainer />) }
const PatientSignup = () => { return (<PatientSignupContainer />) }
const PatientLogin = () => { return (<PatientLoginContainer />) }
const PatientProfile = () => { return (<PatientProfileContainer />) }





export { Dashboard, PatientSignup, PatientLogin, PatientProfile }