import React from 'react'
import { PatientProfile } from '../../components'

export default function Profile() {
    return (
        <div>
            <PatientProfile />
        </div>
    )
}
