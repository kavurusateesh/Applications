import React from 'react'
import { UserSignup } from '../../components'

export default function Signup() {
    return (
        <div>
            <UserSignup />
        </div>
    )
}
