import React from 'react'
import { UserLogin } from '../../components'

export default function Signup() {
    return (
        <UserLogin path="/patient/profile" />
    )
}
