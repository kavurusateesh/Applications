import React from 'react'
import { Box } from '@mui/material';
import { bannerStyles } from '../../Styles/Patient/banner-style'
import { CommonHelthConcerns } from '../../components'

export default function Dashboard() {
    const classes = bannerStyles()
    return (
        <div>
            <Box className={classes.banner}>
            </Box>
            <CommonHelthConcerns />
        </div>
    )
}
