'use strict';

let constants = {
    OTP_EXPTIME: 5 //mins
};

module.exports = Object.freeze(constants); // freeze prevents changes by users